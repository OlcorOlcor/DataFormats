query-5-1:
Query constructs new object with the first Janitor of the dormitory name and their name length.

query-5-2:
Query asks if all the students at the dromitory study at the university that provides the dormitory.

query-5-3:
Query constructs new object with the information if at least one dorm room has a toilet.

query-5-4:
Query constructs array of new objects with the dorm room id and boolean value if the room is full. 